import { SourceCard } from "./SourceCard";

interface Source {
  id: string;
  title: string;
  url: string;
  rating: number;
  synopsis: string;
  category: string;
  isFreeDiscovery: boolean;
}

interface SourceListProps {
  sources: Source[];
  selectedSources: string[];
  onAddToOutline: (id: string) => void;
  onViewSource: (url: string) => void;
  onSummarize: (id: string) => void;
}

export function SourceList({
  sources,
  selectedSources,
  onAddToOutline,
  onViewSource,
  onSummarize,
}: SourceListProps) {
  return (
    <div className="space-y-2">
      {sources.map((source) => (
        <SourceCard
          key={source.id}
          source={source}
          isSelected={selectedSources.includes(source.id)}
          onAddToOutline={() => onAddToOutline(source.id)}
          onViewSource={() => onViewSource(source.url)}
          onSummarize={() => onSummarize(source.id)}
        />
      ))}
    </div>
  );
}
