import { Star, ExternalLink, FileText, Sparkles } from "lucide-react";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Badge } from "./ui/badge";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "./ui/tooltip";
import { useState } from "react";

interface Source {
  id: string;
  title: string;
  url: string;
  rating: number;
  synopsis: string;
  category: string;
  isFreeDiscovery: boolean;
}

interface SourceCardProps {
  source: Source;
  isSelected: boolean;
  onAddToOutline: () => void;
  onViewSource: () => void;
  onSummarize: () => void;
}

export function SourceCard({
  source,
  isSelected,
  onAddToOutline,
  onViewSource,
  onSummarize,
}: SourceCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className="bg-white border-2 border-slate-400 rounded-lg p-2 sm:p-2.5 hover:shadow-md transition-all duration-200"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-center gap-2">
        {/* Checkbox */}
        <Checkbox
          checked={isSelected}
          onCheckedChange={onAddToOutline}
          id={`source-${source.id}`}
          aria-label="Add to outline"
        />

        {/* Main content */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between gap-2">
            <div className="flex-1 min-w-0">
              <h3 className="truncate text-sm sm:text-base">
                {source.title}
              </h3>
              <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="truncate">{source.url}</span>
                {source.isFreeDiscovery && (
                  <>
                    <span>•</span>
                    <span className="text-emerald-600 shrink-0">FREE</span>
                  </>
                )}
                <span>•</span>
                <div className="flex items-center gap-1 shrink-0">
                  <Star className="size-3 fill-yellow-400 text-yellow-400" />
                  <span>{source.rating.toFixed(1)}</span>
                </div>
              </div>
            </div>

            {/* Action buttons */}
            <TooltipProvider delayDuration={300}>
              <div className="flex items-center gap-0.5 shrink-0">
                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={onViewSource}
                        className="h-7 w-7 p-0"
                      >
                        <ExternalLink className="size-3.5" />
                      </Button>
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>View Source</p>
                  </TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={onAddToOutline}
                        className="h-7 w-7 p-0"
                      >
                        <FileText className="size-3.5" />
                      </Button>
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Add to Outline</p>
                  </TooltipContent>
                </Tooltip>

                <Tooltip>
                  <TooltipTrigger asChild>
                    <span>
                      <Button
                        variant="default"
                        size="sm"
                        onClick={onSummarize}
                        className="h-7 w-7 p-0 bg-yellow-100 hover:bg-yellow-200 text-gray-900"
                      >
                        <Sparkles className="size-3.5" />
                      </Button>
                    </span>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>Summarize for $0.02</p>
                  </TooltipContent>
                </Tooltip>
              </div>
            </TooltipProvider>
          </div>

          {/* Expanded content on hover */}
          {isHovered && (
            <div className="mt-2 pt-2 border-t border-slate-200 animate-in fade-in slide-in-from-top-1 duration-200">
              <p className="text-sm text-muted-foreground line-clamp-3">
                {source.synopsis}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}