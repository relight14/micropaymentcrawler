import { useState } from "react";
import { SourceList } from "./components/SourceList";

// Mock data for demonstration
const mockSources = [
  {
    id: "1",
    title: "THE INTERACTION OF JOY RITUALS AND BODY ...",
    url: "dergipark.org.tr",
    rating: 5.0,
    synopsis: "In this study, iconic photographs reflecting the joy rituals of football players are examined through semiotic analysis. Keywords: Joy Ritual,",
    category: "Journalism",
    isFreeDiscovery: true,
  },
  {
    id: "2",
    title: "The Role of Semiotics in Marketing",
    url: "coolerinsights.com",
    rating: 4.7,
    synopsis: "Exploring how semiotics shapes consumer behavior and brand perception through visual and symbolic communication strategies.",
    category: "Journalism",
    isFreeDiscovery: true,
  },
  {
    id: "3",
    title: "Understanding Visual Communication in Digital Media",
    url: "digitalinsights.org",
    rating: 4.9,
    synopsis: "A comprehensive analysis of how digital platforms utilize visual semiotics to enhance user engagement and content delivery.",
    category: "Journalism",
    isFreeDiscovery: true,
  },
  {
    id: "4",
    title: "Cultural Symbols and Brand Identity",
    url: "brandingstudies.com",
    rating: 4.5,
    synopsis: "Examining the intersection of cultural symbolism and modern branding practices in global markets.",
    category: "Journalism",
    isFreeDiscovery: false,
  },
];

export default function App() {
  const [sources, setSources] = useState(mockSources);
  const [selectedSources, setSelectedSources] = useState<string[]>([]);

  const handleAddToOutline = (id: string) => {
    setSelectedSources((prev) =>
      prev.includes(id) ? prev.filter((sid) => sid !== id) : [...prev, id]
    );
  };

  const handleViewSource = (url: string) => {
    window.open(`https://${url}`, "_blank");
  };

  const handleSummarize = (id: string) => {
    console.log("Summarizing source:", id);
    // Add your summarize logic here
  };

  return (
    <div className="min-h-screen bg-gray-50 p-3 sm:p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-4 sm:mb-6">
          <h1 className="mb-2">Research Sources</h1>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-muted-foreground">Filter:</span>
            <div className="inline-flex items-center gap-2 bg-white border rounded-lg px-3 py-1.5">
              <span>📰 Journalism</span>
              <span className="inline-flex items-center justify-center min-w-[1.5rem] h-5 px-1.5 bg-gray-100 rounded text-xs">
                {sources.length}
              </span>
            </div>
          </div>
        </div>

        <SourceList
          sources={sources}
          selectedSources={selectedSources}
          onAddToOutline={handleAddToOutline}
          onViewSource={handleViewSource}
          onSummarize={handleSummarize}
        />
      </div>
    </div>
  );
}