
  # AI Web Search Tool UI

  This is a code bundle for AI Web Search Tool UI. The original project is available at https://www.figma.com/design/eZwF1iueniw9VTmU0jtN8i/AI-Web-Search-Tool-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  